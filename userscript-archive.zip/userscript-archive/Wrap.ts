class Wrap<T> {
  constructor(protected it: T, protected keepNullish = false) {}

  let<R>(
    block: (it: NonNullable<T>) => R
  ): true extends typeof this.keepNullish
    ? null extends T
      ? Wrap<R | null>
      : undefined extends T
      ? Wrap<R | undefined>
      : Wrap<R>
    : null extends R
    ? Wrap<NonNullable<R>> | null
    : undefined extends R
    ? Wrap<NonNullable<R>> | undefined
    : Wrap<R>
  let<R>(block: (it: NonNullable<T>) => R): Wrap<R> | null | undefined {
    const nextValue =
      this.it == null
        ? (this.it as unknown as R)
        : block(this.it as NonNullable<T>)
    if (this.keepNullish) return new Wrap(nextValue)
    return nextValue == null
      ? (nextValue as unknown as null | undefined)
      : new Wrap(nextValue)
  }

  also(block: (it: T) => void) {
    block(this.it)
    return this
  }

  takeIf(predicate: (it: T) => boolean): Wrap<T> | null {
    return predicate(this.it) ? this : null
  }

  takeUnless(predicate: (it: T) => boolean): Wrap<T> | null {
    return predicate(this.it) ? null : this
  }

  run<R>(
    block: () => R
  ): null extends R
    ? Wrap<R> | null
    : undefined extends R
    ? Wrap<NonNullable<R>> | undefined
    : Wrap<R>
  run<R>(block: () => R): Wrap<R> | null | undefined {
    const nextValue = block.call(this.it)
    return nextValue == null
      ? (nextValue as unknown as null | undefined)
      : new Wrap(nextValue)
  }

  apply(block: () => void): Wrap<T> {
    block.call(this.it)
    return this
  }

  throwIfNull(throwable: Error): Wrap<NonNullable<T>> {
    if (this.it == null) throw throwable
    return this as unknown as Wrap<NonNullable<T>>
  }

  valueOrThrow(throwable: Error): NonNullable<T> {
    if (this.it == null) throw throwable
    return this.it as NonNullable<T>
  }

  valueOrElse<R>(orElseValue: R): T | R {
    return this.it == null ? orElseValue : this.it
  }

  private isIterable(iterable: any): iterable is Iterable<unknown> {
    return iterable[Symbol.iterator] === 'function'
  }

  value() {
    return this.it
  }

  array<R>(
    converter: (it: NonNullable<T>) => Iterable<R>
  ): [null] extends [T]
    ? [T] extends [null]
      ? [T] extends [undefined]
        ? ArrayWrap<R, null | undefined>
        : ArrayWrap<R, null>
      : [undefined] extends [T]
      ? ArrayWrap<R, Array<R> | null | undefined>
      : ArrayWrap<R, Array<R> | null>
    : [undefined] extends [T]
    ? [T] extends [undefined]
      ? ArrayWrap<R, undefined>
      : ArrayWrap<R, Array<R> | undefined>
    : ArrayWrap<R, Array<R>>
  array<R>(converter: (it: NonNullable<T>) => Iterable<R>): any {
    if (this.it != null)
      return new ArrayWrap([...converter(this.it as NonNullable<T>)])
    return new ArrayWrap<R, any>(this.it)
  }

  private itIsIterator() {
    return (
      this.it != null &&
      typeof (this.it as NonNullable<any>)[Symbol.iterator] === 'function'
    )
  }
}

function wrap<T>(
  it: T,
  keepNullish?: boolean
): true extends typeof keepNullish
  ? Wrap<T>
  : null extends T
  ? Wrap<NonNullable<T>> | null
  : undefined extends T
  ? Wrap<NonNullable<T>> | undefined
  : Wrap<T>
function wrap<T>(
  it: T,
  keepNullish: boolean = false
): Wrap<T> | null | undefined {
  if (keepNullish) return new Wrap(it, true)
  return it == null ? (it as unknown as null | undefined) : new Wrap(it)
}

class ArrayWrap<
  TR,
  T =
    | Array<TR>
    | (Array<TR> | null)
    | (Array<TR> | undefined)
    | (Array<TR> | null | undefined)
    | null
    | undefined
> extends Wrap<T> {
  map<R>(
    block: (it: TR) => R
  ): [null] extends [T]
    ? [T] extends [null]
      ? [T] extends [undefined]
        ? ArrayWrap<R, null | undefined>
        : ArrayWrap<R, null>
      : [undefined] extends [T]
      ? ArrayWrap<R, Array<R> | null | undefined>
      : ArrayWrap<R, Array<R> | null>
    : [undefined] extends [T]
    ? [T] extends [undefined]
      ? ArrayWrap<R, undefined>
      : ArrayWrap<R, Array<R> | undefined>
    : ArrayWrap<R, Array<R>>
  map<R>(block: (it: TR) => R): any {
    /*
    T returns the actual type of 'it'. TR is the current array item type.

    We need TR to always be the return type of 
    */
    if (this.it != null)
      return new ArrayWrap((this.it as unknown as Array<TR>).map(block))
    else return this as any
  }

  sort(compareFn?: ((a: TR, b: TR) => number) | undefined): ArrayWrap<TR, T> {
    if (this.it != null)
      return new ArrayWrap(
        [...(this.it as unknown as Array<TR>)].sort(compareFn) as any
      )
    else return this
  }
}
