;(() => {
  /*****************\
   * UTILITY ITEMS *
  \*****************/

  /**
   * Logs data with the "Google Userscript:" prefix.
   * @param data The data to log
   */
  function debug(...data: any[]) {
    console.log('Google Userscript:', ...data)
  }

  /**
   * Converts number keys to their count, left to right, 1-indexed.
   */
  const keyToCountMap: Record<string, string> = {
    '1': 'first',
    '2': 'second',
    '3': 'third',
    '4': 'fourth',
    '5': 'fifth',
    '6': 'sixth',
    '7': 'seventh',
    '8': 'eighth',
    '9': 'ninth',
    '0': 'tenth',
  }

  interface ResultElement {
    element: HTMLElement
    x: number
    y: number
    width: number
    height: number
  }

  class ResultsCursor {
    private static _singleton: ResultsCursor | undefined
    private results: ResultElement[][]
    private positionY = -1
    private positionX = 0
    private highlighterEl: HTMLElement

    private constructor() {
      this.results = wrap(document.querySelector('.v7W49e'), true)
        .let(resultEl =>
          resultEl.querySelectorAll<HTMLElement>('a, [jsname="Cpkphb"]')
        )
        .array(it => it)
        .map(el => [el, el.getBoundingClientRect()] as const)
        .map<ResultElement>(([element, boundingRect]) => ({
          element,
          x: window.scrollX + boundingRect.x,
          y: window.scrollY + boundingRect.y,
          width: boundingRect.width,
          height: boundingRect.height,
        }))
        .let(structuredResults => _.groupBy(structuredResults, 'y'))
        .let(groupedResults => {
          const nearbyGroupedResults: ResultElement[][] = []
          Object.values(groupedResults).forEach(group => {
            const mostRecentResult =
              nearbyGroupedResults[nearbyGroupedResults.length - 1]?.[
                nearbyGroupedResults[nearbyGroupedResults.length - 1].length - 1
              ]

            if (
              mostRecentResult != null &&
              group[0].y <= mostRecentResult.y + 5 &&
              group[0].y >= mostRecentResult.y - 5
            ) {
              nearbyGroupedResults[nearbyGroupedResults.length - 1].push(
                ...group
              )
              nearbyGroupedResults[nearbyGroupedResults.length - 1].sort(
                (a, b) => a.x - b.x
              )
            } else nearbyGroupedResults.push(group)
          })

          return nearbyGroupedResults
        })
        .valueOrThrow(Error('Cannot find resuls'))

      //
      //
      //

      const resultsNodeList = document
        .querySelector('.v7W49e')
        ?.querySelectorAll<HTMLElement>('a, [jsname="Cpkphb"]')

      const asdf =
        resultsNodeList == null
          ? null
          : [...resultsNodeList]
              .map(el => [el, el.getBoundingClientRect()] as const)
              .map<ResultElement>(([element, boundingRect]) => ({
                element,
                x: window.scrollX + boundingRect.x,
                y: window.scrollY + boundingRect.y,
                width: boundingRect.width,
                height: boundingRect.height,
              }))

      this.results = wrap(document.querySelector('.v7W49e'), true)
        .let(resultEl =>
          resultEl.querySelectorAll<HTMLElement>('a, [jsname="Cpkphb"]')
        )
        .array(it => it)
        .map(el => [el, el.getBoundingClientRect()] as const)
        .map<ResultElement>(([element, boundingRect]) => ({
          element,
          x: window.scrollX + boundingRect.x,
          y: window.scrollY + boundingRect.y,
          width: boundingRect.width,
          height: boundingRect.height,
        }))
        .let(structuredResults => _.groupBy(structuredResults, 'y'))
        .let(groupedResults => {
          const nearbyGroupedResults: ResultElement[][] = []
          Object.values(groupedResults).forEach(group => {
            const mostRecentResult =
              nearbyGroupedResults[nearbyGroupedResults.length - 1]?.[
                nearbyGroupedResults[nearbyGroupedResults.length - 1].length - 1
              ]

            if (
              mostRecentResult != null &&
              group[0].y <= mostRecentResult.y + 5 &&
              group[0].y >= mostRecentResult.y - 5
            ) {
              nearbyGroupedResults[nearbyGroupedResults.length - 1].push(
                ...group
              )
              nearbyGroupedResults[nearbyGroupedResults.length - 1].sort(
                (a, b) => a.x - b.x
              )
            } else nearbyGroupedResults.push(group)
          })

          return nearbyGroupedResults
        })
        .valueOrThrow(Error('Cannot find resuls'))

      //
      //
      //

      this.highlighterEl = document.createElement('div')
      this.highlighterEl.id = 'csx-google-highlighter'
      this.highlighterEl.style.position = 'absolute'
      this.highlighterEl.style.border = '2px solid rgba(255, 255, 255, 50%)'
      this.highlighterEl.style.borderRadius = '6px'
      const transitionSpeed = '500ms'
      this.highlighterEl.style.transition = `top ${transitionSpeed}, left ${transitionSpeed}, width ${transitionSpeed}, height ${transitionSpeed}`
      this.moveHighlighter(-1, -1, 0, 0)
      document.body.appendChild(this.highlighterEl)
      debug(this.results)
    }

    private moveHighlighter(
      x: number,
      y: number,
      width: number,
      height: number
    ) {
      this.highlighterEl.style.left = `${x - height / 3}px`
      this.highlighterEl.style.top = `${y - height * 0.333}px`
      this.highlighterEl.style.width = `${width + height / 3}px`
      this.highlighterEl.style.height = `${height + height * 0.333}px`
    }

    private updateHighlighter() {
      const { x, y, width, height, element } =
        this.results[this.positionY][this.positionX]

      debug('Moving highligher to element:', element)
      this.moveHighlighter(x, y, width, height)
      if (y < window.scrollY + 64 || y > window.scrollY + window.innerHeight)
        window.scrollTo({ left: 0, top: y - 128, behavior: 'smooth' })
    }

    static get state() {
      if (this._singleton == null) this._singleton = new ResultsCursor()
      return this._singleton
    }

    private findNextXIndex(nextPositionY: number, currentPositionX: number) {
      debug('nextPositionY', nextPositionY)
      debug('currentPositionX', currentPositionX)
      const xIndexWithin = this.results[nextPositionY].findIndex((el, idx) => {
        const currentOffsetX = el.x
        const nextOffsetX = this.results[this.positionY][idx + 1]?.x ?? Infinity
        return (
          currentOffsetX <= currentPositionX && nextOffsetX >= currentPositionX
        )
      })

      debug('xIndexWithin', xIndexWithin)

      return xIndexWithin === -1 ? 0 : xIndexWithin
    }

    moveDown() {
      if (this.positionY === -1 || this.positionY === this.results.length - 1) {
        this.positionY = 0
        this.positionX = 0
      } else {
        this.positionY += 1
        debug(this.positionY, this.positionX)
        this.positionX = this.findNextXIndex(
          this.positionY,
          this.results[this.positionY - 1][this.positionX].x
        )
      }

      this.updateHighlighter()
    }

    moveUp() {
      if (this.positionY <= 0) {
        this.positionY = this.results.length - 1
        this.positionX = 0
      } else {
        this.positionY -= 1
        this.positionX = this.findNextXIndex(
          this.positionY,
          this.results[this.positionY + 1][this.positionX].x
        )
      }

      this.updateHighlighter()
    }

    moveLeft() {
      if (this.positionY === -1) {
        this.positionY = 0
        this.positionX = 0
      } else if (this.positionX > 0) {
        this.positionX -= 1
      }

      this.updateHighlighter()
    }

    moveRight() {
      if (this.positionY === -1) {
        this.positionY = 0
        this.positionX = 0
      } else if (this.positionX < this.results[this.positionY].length - 1) {
        this.positionX += 1
      }

      this.updateHighlighter()
    }

    click() {
      if (this.positionY === -1) return
      this.results[this.positionY][this.positionX].element.click()
    }

    cmdClick() {
      if (this.positionY === -1) return
      const cmdClickEvent = new MouseEvent('click', { metaKey: true })
      this.results[this.positionY][this.positionX].element.dispatchEvent(
        cmdClickEvent
      )
    }
  }

  /************\
   * ELEMENTS *
  \************/

  // Result container, exists at load
  let resultContainer = document.querySelector('.v7W49e')
  if (resultContainer == null)
    debug('Cannot find result container. Was using selector: .v7W49e')

  // Image search anchor, sometimes exists at load
  let imageSearchAnchor = document.querySelector<HTMLAnchorElement>(
    'a[data-hveid="CAEQBQ"]'
  )
  if (imageSearchAnchor == null)
    debug(
      'Cannot find image search anchor. Was using selector: a[data-hveid="CAEQBQ"]'
    )

  // Unavailable at load, so wait til command
  let videoSearchAnchor: HTMLAnchorElement | undefined = undefined

  /******************************\
   * PREDEFINED EVENT LISTENERS *
  \******************************/

  const getIndexListener =
    (keyboardIndex: number) => (event: KeyboardEvent) => {
      if (resultContainer == null)
        return 'Cannot find result container, check logs'

      const targetEl = [...resultContainer.children].filter(
        el =>
          el.tagName === 'DIV' &&
          !el.innerHTML.includes(
            '<span class="q8U8x">People also ask</span>'
          ) &&
          !el.innerHTML.includes('<span>Questions &amp; answers</span>') &&
          !el.classList.contains('exp-outline')
      )[keyboardIndex - 1]

      const anchorEl = targetEl?.querySelector<HTMLAnchorElement>(
        '.yuRUbf > a, .ct3b9e > a'
      )

      anchorEl?.click()
      return 'Opening link'
    }

  /**********************\
   * REGISTER LISTENERS *
  \**********************/

  // Search results
  for (let i = 1; i <= 10; i++) {
    const key = `${i % 10}`
    WebPalette.registerListener(
      key,
      getIndexListener(i),
      `Open the ${keyToCountMap[key]} search result`,
      'Open Results'
    )
  }

  // Open image search
  WebPalette.registerListener(
    'shift+i',
    _ => {
      if (imageSearchAnchor == null) {
        imageSearchAnchor = document.querySelector<HTMLAnchorElement>(
          'a[data-hveid="CAEQBQ"]'
        )
        if (imageSearchAnchor == null)
          return 'Cannot find image search anchor, check logs'
      }

      imageSearchAnchor.click()
    },
    'Open image search',
    'Navigation'
  )

  // Open image search new tab
  WebPalette.registerListener(
    'shift+cmd+i',
    _ => {
      const cmdClickEvent = new MouseEvent('click', { metaKey: true })
      imageSearchAnchor?.dispatchEvent(cmdClickEvent)
    },
    'Open image search in a new tab',
    'Navigation'
  )

  // Open video search
  WebPalette.registerListener(
    'shift+v',
    _ => {
      if (videoSearchAnchor == null) {
        videoSearchAnchor = [
          ...document.querySelectorAll<HTMLAnchorElement>('a[role="menuitem"]'),
        ].find(el => el.innerText.includes('Videos'))
        if (videoSearchAnchor == null) {
          debug(
            'Cannot find video search anchor. Was using selector [role="menuitem"] and then looking for innerText matching "Videos"'
          )
          return
        }
      }

      videoSearchAnchor?.click()
    },
    'Open video search',
    'Navigation'
  )

  // Open video search new tab
  WebPalette.registerListener(
    'shift+cmd+i',
    _ => {
      const cmdClickEvent = new MouseEvent('click', { metaKey: true })
      videoSearchAnchor?.dispatchEvent(cmdClickEvent)
    },
    'Open video search in a new tab',
    'Navigation'
  )

  // Move down
  WebPalette.registerListener(
    'down',
    _ => ResultsCursor.state.moveDown(),
    'Move results cursor down',
    'Result Selection'
  )

  // Move up
  WebPalette.registerListener(
    'up',
    _ => ResultsCursor.state.moveUp(),
    'Move results cursor up',
    'Result Selection'
  )

  // Move left
  WebPalette.registerListener(
    'left',
    _ => ResultsCursor.state.moveLeft(),
    'Move results cursor left',
    'Result Selection'
  )

  // Move right
  WebPalette.registerListener(
    'right',
    _ => ResultsCursor.state.moveRight(),
    'Move results cursor right',
    'Result Selection'
  )

  // Click selection
  WebPalette.registerListener(
    'enter',
    _ => ResultsCursor.state.click(),
    'Open the cursor-selected link',
    'Result Selection'
  )

  // Click selection
  WebPalette.registerListener(
    'cmd+enter',
    _ => ResultsCursor.state.cmdClick(),
    'Open the cursor-selected link in a new tab',
    'Result Selection'
  )
})()
