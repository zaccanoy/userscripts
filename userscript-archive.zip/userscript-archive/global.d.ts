import lodash from 'lodash'

declare global {
  interface Window {
    _: typeof lodash
  }
}
