"use strict";
class Wrap {
    constructor(it, keepNullish = false) {
        this.it = it;
        this.keepNullish = keepNullish;
    }
    let(block) {
        const nextValue = this.it == null
            ? this.it
            : block(this.it);
        if (this.keepNullish)
            return new Wrap(nextValue);
        return nextValue == null
            ? nextValue
            : new Wrap(nextValue);
    }
    also(block) {
        block(this.it);
        return this;
    }
    takeIf(predicate) {
        return predicate(this.it) ? this : null;
    }
    takeUnless(predicate) {
        return predicate(this.it) ? null : this;
    }
    run(block) {
        const nextValue = block.call(this.it);
        return nextValue == null
            ? nextValue
            : new Wrap(nextValue);
    }
    apply(block) {
        block.call(this.it);
        return this;
    }
    throwIfNull(throwable) {
        if (this.it == null)
            throw throwable;
        return this;
    }
    valueOrThrow(throwable) {
        if (this.it == null)
            throw throwable;
        return this.it;
    }
    valueOrElse(orElseValue) {
        return this.it == null ? orElseValue : this.it;
    }
    isIterable(iterable) {
        return iterable[Symbol.iterator] === 'function';
    }
    value() {
        return this.it;
    }
    array(converter) {
        if (this.it != null)
            return new ArrayWrap([...converter(this.it)]);
        return new ArrayWrap(this.it);
    }
    itIsIterator() {
        return (this.it != null &&
            typeof this.it[Symbol.iterator] === 'function');
    }
}
function wrap(it, keepNullish = false) {
    if (keepNullish)
        return new Wrap(it, true);
    return it == null ? it : new Wrap(it);
}
class ArrayWrap extends Wrap {
    map(block) {
        /*
        T returns the actual type of 'it'. TR is the current array item type.
    
        We need TR to always be the return type of
        */
        if (this.it != null)
            return new ArrayWrap(this.it.map(block));
        else
            return this;
    }
    sort(compareFn) {
        if (this.it != null)
            return new ArrayWrap([...this.it].sort(compareFn));
        else
            return this;
    }
}
