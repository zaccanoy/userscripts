type WebPaletteEventHandler = (event: KeyboardEvent) => string | void
const _ = window._

interface WebPaletteListener {
  shift: boolean
  cmd: boolean
  opt: boolean
  ctrl: boolean
  key: string | null
  callback: WebPaletteEventHandler
  description: string
  group: string
}

function preventEventSideEffects(event: KeyboardEvent) {
  event.preventDefault()
  event.stopPropagation()
}

function isPressingMetaOnly(event: KeyboardEvent) {
  return event.key === 'Meta'
}

function isWithinEditable(event: KeyboardEvent) {
  return ['INPUT', 'TEXTAREA'].includes((event.target as HTMLElement).tagName)
}

const wrapKeyHtml = (key: string) => `<kbd>${key}</kbd>`

const cmdKeyHtml = wrapKeyHtml('&#8984;')
const optKeyHtml = wrapKeyHtml('&#8997;')
const ctrlKeyHtml = wrapKeyHtml('&#8963;')
const shiftKeyHtml = wrapKeyHtml('&#8679;')

class WebPaletteClass {
  private static singleton: WebPaletteClass
  private listeners: WebPaletteListener[] = []

  private constructor() {
    document.addEventListener('keydown', this.handleKeydown)
    document.addEventListener('keyup', this.handleKeyup)
  }

  static getSingleton() {
    if (WebPaletteClass.singleton == null)
      WebPaletteClass.singleton = new WebPaletteClass()
    return WebPaletteClass.singleton
  }

  registerListener(
    options: string,
    callback: WebPaletteEventHandler,
    description: string = 'Unknown command',
    group: string = 'Miscellaneous'
  ) {
    const lowercaseOptions = options.toLowerCase()
    const shift = lowercaseOptions.includes('shift')
    const cmd = lowercaseOptions.includes('cmd')
    const opt = lowercaseOptions.includes('opt')
    const ctrl = lowercaseOptions.includes('ctrl')
    const key = wrap(lowercaseOptions)
      .takeUnless(it => ['shift', 'meta', 'alt', 'control'].includes(it))
      ?.let(it => it.match(/[A-Za-z0-9 ,./;'\[\]\\\-=`]+$/))
      ?.let(regExArray => regExArray[0].toLowerCase())
      ?.value() as string | null

    this.listeners.push({
      shift,
      cmd,
      opt,
      ctrl,
      key,
      callback,
      description,
      group: ['misc', 'miscellaneous'].includes(group.toLowerCase())
        ? 'Miscellaneous'
        : group,
    })

    this.renderCommandPalette()
  }

  private renderCommandPalette() {
    const groupedListeners = _.groupBy(this.listeners, 'group')

    const tagName = 'div'
    const id = 'csx-command-palette'
    const innerHTML = `
      <div id='csx-command-palette-inner'>
        ${Object.entries(groupedListeners)
          .map(([groupName, listeners]) => {
            return `
              <section id='csx-web-palette-group-${groupName}'>
                <h2>${groupName}</h2>
                <dl>
                  ${listeners
                    .map(({ cmd, opt, ctrl, shift, key, description }) => {
                      const shortcut = [
                        ctrl && ctrlKeyHtml,
                        opt && optKeyHtml,
                        shift && shiftKeyHtml,
                        cmd && cmdKeyHtml,
                        key && wrapKeyHtml(key),
                      ]
                        .filter(item => !!item)
                        .join(' + ')

                      return `
                        <div class='csx-detail-container'>
                          <dt>${shortcut}</dt>
                          <dd>${description}</dd>
                        </div>
                      `
                    })
                    .join('\n')}
                </dl>
              </section>
            `
          })
          .join('\n')}
      </div>
    `

    document.getElementById(id)?.remove()
    const commandPaletteElement = document.createElement(tagName)
    commandPaletteElement.id = id
    commandPaletteElement.innerHTML = innerHTML
    document.body.appendChild(commandPaletteElement)
  }

  private renderToast(content: string) {
    const tagName = 'div'
    const id = 'csx-web-palette-toast'
    const innerHTML = `
      <p>${content}</p>
      <button
        onclick="document.body.classList.remove('csx-web-palette-show-toast')"
      >
        &times;
      </button>
    `

    document.getElementById(id)?.remove()
    const toastElement = document.createElement(tagName)
    toastElement.id = id
    toastElement.innerHTML = innerHTML
    document.body.appendChild(toastElement)
  }

  private handleKeyup = (event: KeyboardEvent) => {
    if (isWithinEditable(event)) return

    if (isPressingMetaOnly(event))
      document.body.classList.remove('csx-show-palette')
  }

  private handleKeydown = (event: KeyboardEvent) => {
    if (isWithinEditable(event)) return

    if (isPressingMetaOnly(event)) {
      document.body.classList.add('csx-show-palette')
    }

    const paletteCode = (_ => {
      switch (event.code) {
        case 'Space':
          return ['space', ' ', 'spacebar']
        case 'ArrowLeft':
          return ['arrowleft', 'leftarrow', 'left']
        case 'ArrowRight':
          return ['arrowright', 'rightarrow', 'right']
        case 'ArrowUp':
          return ['arrowup', 'uparrow', 'up']
        case 'ArrowDown':
          return ['arrowdown', 'downarrow', 'down']
        case 'Comma':
          return [',', 'comma']
        case 'Period':
          return ['.', 'period', 'dot']
        case 'Slash':
          return ['/', 'forwardslash', 'slash']
        case 'Semicolon':
          return [';', 'semi', 'semicolon']
        case 'Quote':
          return ["'", 'quote', 'singlequote', 'quotesingle']
        case 'BracketLeft':
          return ['[', 'bracketleft', 'leftbracket', 'leftsquarebracket']
        case 'BracketRight':
          return [']', 'bracketright', 'rightbracket', 'rightsquarebracket']
        case 'Backslash':
          return ['\\', 'backslash']
        case 'Minus':
          return ['-', 'minus', 'dash']
        case 'Equal':
          return ['=', 'equal', 'equals', 'eq']
        case 'Backquote':
          return ['`', 'backquote', 'backtick']
        case 'Escape':
          return ['esc', 'escape']
        case 'CapsLock':
          return ['caps', 'capslock']
        default:
          return [
            event.code.replace('Digit', '').replace('Key', '').toLowerCase(),
          ]
      }
    })()

    for (const {
      shift,
      cmd,
      opt,
      ctrl,
      key,
      callback,
      group,
      description,
    } of this.listeners) {
      if (
        !!shift == event.shiftKey &&
        !!cmd == event.metaKey &&
        !!opt == event.altKey &&
        !!ctrl == event.ctrlKey &&
        (paletteCode.includes(key!) ||
          (key == null &&
            ['Shift', 'Meta', 'Alt', 'Control'].includes(event.key)))
      ) {
        preventEventSideEffects(event)
        const result = callback(event)
        if (result) {
          this.renderToast(result)
          document.body.classList.add('csx-web-palette-show-toast')
          window.setTimeout(
            () =>
              document.body.classList.remove('csx-command-palette-show-toast'),
            5000
          )
        }
      }
    }
  }
}

const WebPalette = WebPaletteClass.getSingleton()
